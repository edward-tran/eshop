<!DOCTYPE html>
<html>
<head>
    <title>Nicesnippets.com</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
   
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\eshop\resources\views/myDemoMail.blade.php ENDPATH**/ ?>