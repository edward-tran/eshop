
<?php $__env->startSection('title'); ?>
Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card" style="margin: 20px 20px; border-radius:20px; width:65%;">
        <div class="card-header" style="border-top-left-radius:20px; border-top-right-radius: 20px;" >
            <h4>Users</h4>
        </div>
        <div class="card-body">
        <table style="text-align: center;">
        <thead class="col-md-12">
            <tr style="font-weight: bold;">
                <td class="col-md-2">Name</td>
                <td class="col-md-3">Email</td>
                <td class="col-md-3" >Address</td>
                <td class="col-md-2" >Phone Number</td>
                <td class="col-md-3"></td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="padding-left:20px;">
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->address); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td>
                    <a href="<?php echo e(url('user/user-detail/'.$user->id)); ?>" class="btn btn-primary" style="border-radius: 30px;">Detail</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/admin/user/index.blade.php ENDPATH**/ ?>