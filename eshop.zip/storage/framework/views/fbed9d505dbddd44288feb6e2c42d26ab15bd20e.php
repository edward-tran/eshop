
<?php $__env->startSection('title'); ?>
Categories
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(\Session::has('message')): ?>
        <div class="alert alert-success">
            <ul>
                <li><?php echo \Session::get('message'); ?></li>
            </ul>
        </div>
    <?php endif; ?>
    <div class="card" style="margin: 20px 20px; border-radius:20px;">
        <div class="card-header" style="border-top-left-radius:20px; border-top-right-radius: 20px;">
            <h3>Category List</h3>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <th style="text-align:center;">ID</th>
                    <th style="text-align:center;" class="w-25">Name</th>
                    <th style="text-align:center;" class="w-25">Description</th>
                    <th style="text-align:center;">Image</th>
                    <th style="text-align:center;">Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align:center;"><?php echo e($category->id); ?></td>
                            <td style="text-align:center;"><?php echo e($category->name); ?></td>
                            <td style="text-align:center;"><?php echo e($category->description); ?></td>
                            <td style="text-align:center;">
                                <img src="<?php echo e(asset('assets/uploads/categories/'.$category->image )); ?>" class="h-25 w-25">
                            </td>
                            <td class="w-25 h-25" style="text-align: center;">
                                <a class="btn btn-primary" href="<?php echo e(url('edit-category', $category->id)); ?>">Edit</a>
                                <a class="btn btn-danger" href="<?php echo e(url('delete-category', $category->id)); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/admin/category/index.blade.php ENDPATH**/ ?>