<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/bootstrap5.css')); ?>" rel="stylesheet" />
</head>
<body>
    <div class="content">
    <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('frontend/js/bootstrap5.bundle.min.js')); ?>"></script>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\eshop\resources\views/layouts/front.blade.php ENDPATH**/ ?>