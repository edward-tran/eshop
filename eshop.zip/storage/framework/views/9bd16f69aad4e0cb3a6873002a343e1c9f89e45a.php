<footer class="py-3  mt-auto" style="background-color: #94a3ba;">
    <div class="container-fluid px-4" >
        <div class="d-flex align-items-center justify-content-between small" >
            <div style="color:white;">Mobile World &copy; Designed by Edward in 2022</div>
            <div>
                <a href="https://www.facebook.com/sangtranwp/" style="color:white;">Facebook</a>
                    &middot;
                <a href="#" style="color:white;">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\eshop\resources\views/layouts/inc/home_footer.blade.php ENDPATH**/ ?>