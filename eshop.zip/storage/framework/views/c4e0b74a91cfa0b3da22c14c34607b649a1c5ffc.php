

<?php $__env->startSection('title'); ?>
    Mobile World - Điện thoại
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.inc.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="py-5">
        <div class="container">
            <div class="row">
                <h4 style="color:#fdf2f3; margin-bottom:10px;">Các sản phẩm nổi bật</h4>
                <div class="owl-carousel owl-theme">
                <?php $__currentLoopData = $featuredCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuredCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuredProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item" >
                        <a href="<?php echo e(url('category/'.$featuredCategory->slug.'/'.$featuredProduct->slug )); ?>">
                        <div class="card" style="border-radius: 15px;">
                            <div style=" margin-top:-1px; margin-left: -2px; color:white; background-color:red; width:100px; height:30px; border-top-right-radius: 25px; border-bottom-right-radius:25px; border-top-left-radius:8px; padding-left: 10px; padding-top: 2px;">Giảm <?php echo e(ceil(($featuredProduct->original_price - $featuredProduct->selling_price)/$featuredProduct->original_price * 100)); ?>%</div>
                                <img style="margin-top:10px;" height="350px" src="<?php echo e(asset('assets/uploads/products/'.$featuredProduct->image)); ?>" alt="">
                                <div class="card-body">
                                    <h5><?php echo e($featuredProduct->name); ?></h5>
                                    <span class="float-start" style="color:red;"><?php echo e($featuredProduct->selling_price); ?>&#8363</span>
                                    <span class="float-end" style="color:black;"><s><?php echo e($featuredProduct->original_price); ?>&#8363</s></span>
                                </div>
                        </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </div>
            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <h4 style="color:#fdf2f3; margin-bottom:10px;">Các hãng được ưa chuộng</h4>
                <div class="owl-carousel owl-theme">
                    <?php $__currentLoopData = $featuredCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuredCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item" >
                    <a href="<?php echo e(url('category/'.$featuredCategory->slug)); ?>">
                        <div class="card" style="border-radius: 15px; background-color:#f8f8f8;">
                            <img style="margin-top:10px;" height="200px" src="<?php echo e(asset('assets/uploads/categories/'.$featuredCategory->image)); ?>" alt="">
                            <div class="card-body" >
                                <h5><?php echo e($featuredCategory->name); ?></h5>
                                <p>
                                    <?php echo e($featuredCategory->description); ?>

                                </p>
                            </div>
                        </div>
                    </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $('.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        dots:false,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:3
            },
            1000:{
                items:3
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/homepage/index.blade.php ENDPATH**/ ?>