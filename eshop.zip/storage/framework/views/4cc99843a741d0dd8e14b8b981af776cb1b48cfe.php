

<?php $__env->startSection('title'); ?>
Eshop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Welcome</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/frontend/index.blade.php ENDPATH**/ ?>