<nav class="navbar navbar-expand-lg " style="background-color: #94a3ba;">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>" style="margin-left: 30px; color:white;">Mobile World </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent" style="margin-right:30px;">
    <ul class="navbar-nav ms-auto">
      <li class="nav-item active">
        <a style="color:#fdf2f3;" class="nav-link" href="<?php echo e(url('/')); ?>">
        <i class="fa fa-home" aria-hidden="true"></i>
        Trang chủ</a>
      </li>
      <li class="nav-item">
        <a style="color:#fdf2f3;" class="nav-link" href="<?php echo e(url('category')); ?>">
        <i class="fa fa-list-alt" aria-hidden="true"></i>
        Thương hiệu</a>
      </li>
      <li class="nav-item">
        <a style="color:#fdf2f3;" class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="fas fa-sign-out-alt"></i> <?php echo e(__('Logout')); ?>

        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
        </form>
        </a>
        </li>
    </ul>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\eshop\resources\views/layouts/inc/user_nav.blade.php ENDPATH**/ ?>