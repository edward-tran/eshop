

<?php $__env->startSection('title'); ?>
Order completed
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card" class="card" style="margin: 20px 20px; border-radius:20px; width:75%;">
    <div class="card-header" style="border-top-left-radius:20px; border-top-right-radius: 20px;">
        <h4>Order completed</h4>
    </div>
    <div class="card-body">
    <table style="text-align: center;">
        <thead class="col-md-12">
            <tr style="font-weight: bold;">
                <td class="col-md-2">Order Date</td>
                <td class="col-md-2">Tracking Number</td>
                <td class="col-md-2">Total Price</td>
                <td class="col-md-2">Status</td>
                <td class="col-md-4">Payment Method</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="padding-left:20px;">
                <td><?php echo e(date('d-m-Y', strtotime( $order->created_at ))); ?></td>
                <td><?php echo e($order->tracking_no); ?></td>
                <td><?php echo e($order->total_price); ?></td>
                <td style="color:#50C878; font-weight:bold;"><?php echo e($order->status == 0 ? 'Đang chờ' : 'Hoàn thành'); ?></td>
                <td><?php echo e($order->payment_method); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/admin/order/order_completed.blade.php ENDPATH**/ ?>