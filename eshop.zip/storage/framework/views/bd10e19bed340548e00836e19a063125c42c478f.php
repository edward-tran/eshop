

<?php $__env->startSection('title'); ?>
    Điện thoại <?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h4 id="navbar-sub">
        <a href="/">Trang chủ</a>
        <i class="fas fa-chevron-right fa-sm"></i>
        <a href="<?php echo e(url('category')); ?>">Hãng</a> 
        <i class="fas fa-chevron-right fa-sm"></i> 
        <?php echo e($category->name); ?>

    </h4>

    <div class="py-5">
        <div class="container">
            <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-3" >
                        <div class="card" style="border-radius: 15px;">
                            <a href="<?php echo e(url('category/'.$category->slug.'/'. $product->slug)); ?>">
                            <img style="margin-top:10px; height:300px;"  src="<?php echo e(asset('assets/uploads/products/'.$product->image)); ?>" alt="">
                            <div class="card-body" style="border-radius: 15px; ">
                                <h5 style="height:50px;"><?php echo e($product->name); ?></h5>
                                <span class="float-start" style="color:red;"><?php echo e($product->selling_price); ?>&#8363</span>
                                <span class="float-end" style="color:black;"><s><?php echo e($product->original_price); ?>&#8363</s></span>
                            </div>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/homepage/product/index.blade.php ENDPATH**/ ?>