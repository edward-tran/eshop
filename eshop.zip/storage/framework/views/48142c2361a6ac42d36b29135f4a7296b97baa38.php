
<?php $__env->startSection('title'); ?>
Users Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card" style="margin: 20px 20px; border-radius:20px; width:75%;">
        <div class="card-header" style="border-top-left-radius:20px; border-top-right-radius: 20px;" >
            <h4>Users Detail</h4>
        </div>
        <div class="card-body">
        <table style="text-align: center;">
        <thead class="col-md-12">
            <tr style="font-weight: bold;">
                <td class="col-md-1">Name</td>
                <td class="col-md-">Email</td>
                <td class="col-md-2" >Address</td>
                <td class="col-md-2" >Phone Number</td>
                <td class="col-md-1">Role</td>
                <td class="col-md-2">Created Date</td>
                <td class="col-md-2">Updated Date</td>
            </tr>
        </thead>
        <tbody>
            <tr style="padding-left:20px;">
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->address); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e($user->role_as == '1' ? 'admin' : 'user'); ?></td>
                <td><?php echo e(date('d-m-Y', strtotime( $user->created_at ))); ?></td>
                <td><?php echo e(date('d-m-Y', strtotime( $user->updated_at ))); ?></td>
            </tr>
        </tbody>
    </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/admin/user/user_detail.blade.php ENDPATH**/ ?>