

<?php $__env->startSection('title'); ?>
    Các hãng điện thoại
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h4 style="color:white; margin-top:10px; margin-left:120px;">
    <a style="color:white;" href="/">Trang chủ </a>
    <i class="fas fa-chevron-right fa-sm"></i> 
    <a style="color:white;" href="<?php echo e(url('category')); ?>">Hãng</a> 
</h4>
<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col md-3 mb-3">
                            <a href="<?php echo e(url('category', $category->slug)); ?>">
                                <div class="card" style="border-radius: 15px; background-color:#f8f8f8; width: 500px; height:400px;">
                                        <img style="margin-top:10px;" src="<?php echo e(asset('assets/uploads/categories/'.$category->image)); ?>" alt="">
                                    <div class="card-body">
                                        <h5><?php echo e($category->name); ?></h5>
                                        <p>
                                            <?php echo e($category->description); ?>

                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/homepage/category.blade.php ENDPATH**/ ?>