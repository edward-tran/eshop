
<?php $__env->startSection('title'); ?>
Danh sách đơn hàng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="wrapper" style="padding:10px; height:auto;">
    <div style="padding:10px; font-weight:bold; font-size:20px; text-align:center;">Danh sách đơn hàng</div>
    <hr>
    <table>
        <thead>
            <tr style="font-weight: bold;">
                <td class="col-md-4">Tracking Number</td>
                <td class="col-md-3" >Tổng tiền</td>
                <td class="col-md-3" >Trạng thái</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="padding-left:20px;">
                <td><?php echo e($order->tracking_no); ?></td>
                <td><?php echo e($order->total_price); ?></td>
                <td><?php echo e($order->status == 0 ? 'Đang chờ' : 'Hoàn thành'); ?></td>
                <td>
                    <a href="<?php echo e(url('order-detail/'.$order->id)); ?>" class="btn btn-primary" style="border-radius:30px;">Xem đơn hàng</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/homepage/order/index.blade.php ENDPATH**/ ?>