
<?php $__env->startSection('title'); ?>
Thông tin khách hàng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper" id="user-detail" >
            <div>
                <h4><img src="<?php echo e(asset('assets/img/information.png')); ?>" alt="info-icon">Thông tin khách hàng</h4>
            </div>
            <hr>
            <form action="<?php echo e(url('update-user-detail/'.$user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
                <div id="user-detail-form">
                    <div class="col-md-12" style="display: inline-block;">
                        <label class="col-md-6 mb-3 user-detail-label" for="">Tên khách hàng</label>
                        <input class="col-md-6 mb-3 user-detail-input" name="name" type="text" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="col-md-12" style="display: inline-block;">
                        <label class="col-md-6 mb-3 user-detail-label" for="">Email</label>
                        <input class="col-md-6 mb-3 user-detail-input" name="email" type="text" value="<?php echo e($user->email); ?>">
                    </div>
                    <div class="col-md-12" style="display: inline-block;">
                        <label class="col-md-6 mb-3 user-detail-label" for="">Địa chỉ</label>
                        <input class="col-md-6 mb-3 user-detail-input" name="address" type="text" value="<?php echo e($user->address); ?>">
                    </div>
                    <div class="col-md-12" style="display: inline-block;">
                        <label class="col-md-6 mb-3 user-detail-label" for="">Số điện thoại</label>
                        <input class="col-md-6 mb-3 user-detail-input" name="phone" type="text" value="<?php echo e($user->phone); ?>">
                    </div>
                    <div class="col-md-12" style="display: inline-block;">
                        <div style="float: left;" class="col-md-10">
                        </div>
                        <div style="float:right;" class="col-md-2">
                            <button type="submit" class="btn btn-primary right" style="border-radius: 30px;">Cập nhật</button>
                        </div>
                    </div>
                </div>
            </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eshop\resources\views/homepage/user_detail.blade.php ENDPATH**/ ?>